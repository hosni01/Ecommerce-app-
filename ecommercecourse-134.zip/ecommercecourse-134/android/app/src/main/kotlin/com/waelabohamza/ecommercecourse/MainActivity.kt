package com.waelabohamza.ecommercecourse

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
